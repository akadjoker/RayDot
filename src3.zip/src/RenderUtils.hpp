#pragma once

#include "Math.hpp"

void RenderTransformFlipClip(Texture2D texture, int width, int height, Rectangle clip, bool flipX, bool flipY, Color color, const Matrix2D &matrix, int blend);
void RenderTransform(Texture2D texture, const Matrix2D &matrix, const Color &c, int blend);
void  RenderTextureRotateSizeRad(Texture2D texture,float x, float y,float spin, float size,  bool flipx, bool flipy, Color c);