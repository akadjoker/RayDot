#pragma once
#include "Core.hpp"
#include "Utils.hpp"
#include "Scene.hpp"


class Game;

class State
{
public:
    State(const std::string &name);
    virtual ~State();

    virtual void ready();
    virtual void update(double deltaTime);
    virtual void render() ;
    virtual void destroy();

    const std::string &getName() const;

private:
    friend class Game;
    std::string name;
    
};


class  Game
{
    public :
        Game() ;
        virtual ~Game() ;

        void Init(int width, int height, const std::string& title);
        void Quit();
        bool IsRunning() ;

        void Update();
        void Render();

        State *AddState(State *state);
        bool  ChangeState(const std::string &stateName);

        
        static Game* Instance();
    private :
        static Game* m_instance;
        friend class State;
        State* m_currentState;
        State* m_nextState;
        std::vector<State*> m_states;
        bool    m_running;

};
    