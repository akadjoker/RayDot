#include "Game.hpp"

State::State(const std::string &name): name(name)
{
}

State::~State()
{
}

void State::ready()
{
}

void State::update(double deltaTime)
{
}

void State::render()
{
}

void State::destroy()
{
}

const std::string &State::getName() const
{
    return name;
}

Game *Game::m_instance = nullptr;

Game *Game::Instance()
{
    return m_instance;
}

Game::Game()
{
    m_instance = this;
    m_running = false;
    m_currentState = nullptr;
    m_nextState = nullptr;
}

Game::~Game()
{
    if (m_running)
    {
        Quit();
    }
}

void Game::Init(int width, int height, const std::string &title)
{
    InitWindow(width, height, title.c_str());

}

void Game::Quit()
{
    m_running = false;
    for (auto state : m_states)
    {
        state->destroy();
        delete state;
        state = nullptr;
    }
    CloseWindow(); 
}

bool Game::IsRunning() 
{
    m_running = !WindowShouldClose();
    return m_running;
}

void Game::Update()
{   
    if (m_nextState != nullptr)
    {
        if (m_currentState != nullptr)
        {
            m_currentState->destroy();
        }
        m_currentState = m_nextState;
        m_currentState->ready();
        m_nextState = nullptr;
    }


    if (m_currentState != nullptr)
    {
        m_currentState->update(GetFrameTime());
    }
}

void Game::Render()
{
    if (m_currentState != nullptr)
    {
        m_currentState->render();
    }
}

State *Game::AddState(State *state)
{
    m_states.push_back(state);
    return state;
}

bool Game::ChangeState(const std::string &stateName)
{
    for (auto state : m_states)
    {
        if (state->getName() == stateName)
        {
            m_nextState = state;
            return true;
        }
    }
    return false;
}
