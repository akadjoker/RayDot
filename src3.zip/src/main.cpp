#include "RayGot.hpp"
#include "Utils.hpp"
#include <raymath.h>

float skewX = 0.0f;
float skewY = 0.0f;

const int screenWidth = 800;
const int screenHeight = 450;


Color RandomRGBColor()
{
    Color c;
    c.r =(unsigned char) GetRandomValue(0, 255);
    c.g =(unsigned char) GetRandomValue(0, 255);
    c.b =(unsigned char) GetRandomValue(0, 255);
    c.a = 255;
    return c;
}
  



class Player : public Node2D
{
    public:
      Vector2 speed;
      float width = 32;
      float height = 32;
      float live;

    Player():Node2D("Player")
    {
       addChild(new CircleShape2D(20));

       addChild(new Sprite2D("sprite", "wabbit"));

     //  addChild(new Sprite2D("sprite2", "zazaka"));
     
       live =GetRandomValue(50, 100);  
       width  = 32;
       height = 32;
       origin = {width/2, height/2};
       
    }
    void ready()
    {
         position.x = GetRandomValue(-200, screenWidth+200);
         position.y = GetRandomValue(-200, screenHeight+200);
         speed.x = (float)GetRandomValue(-250, 250)/60.0f;
         speed.y = (float)GetRandomValue(-250, 250)/60.0f;

        Sprite2D *sprite = (Sprite2D*)getChildByName("sprite");
        sprite->color = (Color){ (unsigned char)GetRandomValue(50, 240),
                                        (unsigned char)GetRandomValue(80, 240),
                                      (unsigned char)  GetRandomValue(100, 240), 255 };

    }

    void update(double deltaTime)
    {
        live -= 5 * deltaTime *10;//24 fps
       // if (live < 0) done = true;
        // position.x += speed.x;
        // position.y += speed.y;

            if (((position.x + width/2) > GetScreenWidth()) ||
                ((position.x + width/2) < 0)) speed.x *= -1;
            if (((position.y + height/2) > GetScreenHeight()) ||
                ((position.y + height/2 - 40) < 0)) speed.y *= -1;

    }
  
};

class Nave: public Node2D
{
    Sprite2D *main;
    Sprite2D *left;
    Sprite2D *rigth;
    View *view;
    float fx =0.2;
    NodeEmitter2D *emitter;
    public:
    Nave():Node2D("Nave")
    {
      

      //  origin = {16, 16};
    }
    void ready()
    {
        main   =new Sprite2D("nave", "nave");
        left   =new Sprite2D("left", "cano");
        rigth  =new Sprite2D("right", "cano");
        
         origin = {99/2, 75/2};

        left->move(10, 10);
        rigth->move(70, 10);

        addChild(main);
        addChild(left);
        addChild(rigth);
        addChild(new CircleShape2D(40,99/2,75/2));

        emitter = new NodeEmitter2D("emitter","particle", 50, false);
            emitter->SetFrequency(60);

            float life = 0.8;

            emitter->SetLife(life);
            emitter->SetAngle(45);
            emitter->SetAlphaStart(255, 0);
            emitter->SetAlphaEnd(0, life*2);
            
            emitter->SetSizeStart(0.5, 0);
            emitter->SetSizeEnd(1.9f, life);

            emitter->SetColorStart(55, 55, 55, 0);
            emitter->SetColorEnd(255, 255, 255, life*2);
            emitter->SetStartZone(0, 0, 0, 0);

            emitter->SetScreenSpace(true);
            emitter->SetDirection(0, fx);
            emitter->SetSelocityRange(0.5,2);
            //emitter->SetEmitterPosition(200, 200);
            emitter->position = {50,90};
            addChild(emitter);




        position = {screenWidth/2-200, screenHeight/2};

    //  view = new View();
    //  view->setViewPort(0, 0, (float)screenWidth/2, (float)screenHeight);
    //  view->setOffset((screenWidth/2)/2, screenHeight/2);
    //  scene->addView(view);


    }
    void update(double deltaTime)
    {
        
       if (IsKeyDown(KEY_A)) rotation += 50 * deltaTime *10;
       if (IsKeyDown(KEY_D)) rotation -= 50 * deltaTime *10;  
       if (IsKeyDown(KEY_W)) 
       {
        fx += 10;
        advance(50 * deltaTime *10,rotation+90); 
        emitter->SetFrequency(60);
       } else 
       {
        fx =10;
        emitter->SetFrequency(20);
       }
       if (fx >80)
        {
            fx = 80;
        }
       emitter->SetDirection(0, fx);

       // emitter->SetEmitterPosition(position.x,position.y);
     //   emitter->SetAngle(rotation+90);

    
     //  view->folow(position); 
    }
    void draw()
    {
        
      

    }
};

class Enemy : public Node2D
{
    Sprite2D *main;
    Sprite2D *left;
    Sprite2D *rigth;
    View *view;
    public:
    Enemy():Node2D("enemy")
    {
    }
    void ready()
    {
        main   =new Sprite2D("nave", "nave");
        left   =new Sprite2D("left", "cano");
        rigth  =new Sprite2D("right", "cano");
        
        main->color = RED;

        left->move(10, 10);
        rigth->move(70, 10);

        addChild(main);
        main->addChild(left);
        main->addChild(rigth);
        origin = {99/2, 75/2};
        addChild(new RectangleShape2D(99,75,origin.x,origin.y));


        position = {screenWidth/2+200, screenHeight/2};
        

         view = new View();
         view->setViewPort((float)screenWidth/2, 0, (float)screenWidth/2, (float)screenHeight);
         view->setOffset((screenWidth/2)/2, screenHeight/2);
         scene->addView(view);

        //View view;
       // view.setViewPort({(float)screenWidth/2, 0, (float)screenWidth/2, (float)screenHeight});
       // scene.addView(&view);
    }
    void update(double deltaTime)
    {
       if (IsKeyDown(KEY_J)) rotation += 50 * deltaTime *10;
       if (IsKeyDown(KEY_L)) rotation -= 50 * deltaTime *10; 
        if (IsKeyDown(KEY_I)) advance(50 * deltaTime *10,rotation+90);    
    
       view->folow(position); 
              
    }
    void draw()
    {
       
        
        
    }
};


void setViewPort(float x, float y, float w, float h)
{

    int     viewportTop = screenHeight - (y + h);
    rlViewport((int)x, viewportTop, (int)w, (int)h);
  
}



int main()
{
    

    InitWindow(screenWidth, screenHeight, "raygot");
    Scene *scene = Scene::Instance();

    scene->setClearColor({0,0,45,255});
    

    Assets::Instance().loadGraph("zazaka", "zazaka.png");
    Assets::Instance().loadGraph("wabbit", "wabbit_alpha.png");
    Assets::Instance().loadGraph("nave", "playerShip1_orange.png");
    Assets::Instance().loadGraph("cano", "gun02.png");
    Assets::Instance().loadGraph("rpg", "walkcycle.png");

    Assets::Instance().loadGraph("run", "Run.png");
    Assets::Instance().loadGraph("jump", "Jump.png");

    Assets::Instance().loadGraph("particle", "fire.png");

    Node *node = new Node("wabyt");

    AnimatedSprite2D *nodePlayer = new AnimatedSprite2D("animation");
    nodePlayer->loop = false;
    nodePlayer->addFrame("all", "rpg", 12, 64, 64, 0);
    nodePlayer->setPosition(100, 100);
    nodePlayer->setScale(2, 2);
    nodePlayer->play("all",19, 26);
    scene->Add(nodePlayer);

    AnimatedSprite2D *nodePlayer2 = new AnimatedSprite2D("animation2");
    
    nodePlayer2->addFrame("run", "run", 6, 64, 64, 0);
    nodePlayer2->addFrame("jump", "jump", 8, 64, 64, 0);

    nodePlayer2->setPosition(300, 100);
    nodePlayer2->setScale(2, 2);
    nodePlayer2->play("run");
    nodePlayer2->loop = false;
    scene->Add(nodePlayer2);

//     NodeEmitter2D *emitter = new NodeEmitter2D("emitter","particle", 250, false);
//     emitter->SetFrequency(60);
//     emitter->SetLife(0.8);


//     emitter->SetAngle(-90);
// //    emitter->SetDirection(-90.0);

//     emitter->SetAlphaStart(255, 0);
//     emitter->SetAlphaEnd(0, 0.8);

//     emitter->SetSizeStart(0.5, 0);
//     emitter->SetSizeEnd(2.5f, 0.8);

//     emitter->SetColorStart(255, 0, 255, 0);
//     emitter->SetColorEnd(255, 255, 255, 0.8);

//     emitter->SetStartZone(0, 0, 0, 0);

//     emitter->SetScreenSpace(true);

    

//     scene->Add(emitter);







    scene->Add(node);    
    
    // scene->Add(new Enemy());
    scene->Add(new Nave());
    

    // Nave *player = new Nave();
    // player->OnReady();
    // Enemy   *enemy = new Enemy();
    // enemy->OnReady();

    

    

    while (!WindowShouldClose())       
    {
     
        BeginDrawing();

        if (IsMouseButtonDown(1))
        {
            for (int i = 0; i < 100; i++)
            {
               // node->addChild(new Player());
                scene->Add(new Player());
            }
               
        }

        //emitter->SetPosition(GetMouseX(), GetMouseY()   );


        scene->Update();

        if (IsKeyDown(KEY_D)) 
        {
            nodePlayer->play("all",28, 35);
          //  nodePlayer->advance(1,0);
        }else
        if (IsKeyDown(KEY_A)) 
        {
            nodePlayer->play("all",10, 17);
           // nodePlayer->advance(1,0);
        }

        if (IsKeyDown(KEY_W)) 
        {
            nodePlayer->play("all",1, 8);
           // nodePlayer->advance(1,0);
        }else 
        if (IsKeyDown(KEY_S)) 
        {
            nodePlayer->play("all",19, 26);
           // nodePlayer->advance(1,0);
        }

        if (IsKeyDown(KEY_J)) 
        {
            nodePlayer2->play("run");
            nodePlayer2->setLoop(true);
            nodePlayer2->flipX = false;
        } else 
        if (IsKeyDown(KEY_L)) 
        {
            nodePlayer2->play("run");
            nodePlayer2->flipX = true;
            nodePlayer2->setLoop(true);
        }

        if (IsKeyDown(KEY_I)) 
        {
            nodePlayer2->play("jump");
            nodePlayer2->setLoop(false);
        } else 
        {
             if (nodePlayer2->IsStopped("jump"))
             {
                 nodePlayer2->play("run");
                nodePlayer2->setLoop(true);
             }
        }



       /*
    walkUp: [1, 8],
    walkLeft: [10, 17],
    walkDown: [19, 26],
    walkRight: [28, 35]
*/

       // View view;
        //view.setView({(float)screenWidth/2, 0, (float)screenWidth/2, (float)screenHeight});
        //view.setView({0, 0, (float)screenWidth/2, (float)screenHeight});
        //Scene::Instance().setView(view);

        // enemy->OnUpdate(GetFrameTime());
        // player->OnUpdate(GetFrameTime());

        // setViewPort(0, 0, (float)screenWidth/2, (float)screenHeight);
        // BeginScissorMode(0, 0, (float)screenWidth/2, (float)screenHeight);
        // scene.Draw();
        // enemy->OnDraw();
        // player->OnDraw();  
        // EndScissorMode();


        // setViewPort((float)screenWidth/2, 0, (float)screenWidth/2, (float)screenHeight);
        // BeginScissorMode((float)screenWidth/2, 0, (float)screenWidth/2, (float)screenHeight);
        // scene.Draw();
        // enemy->OnDraw();
        // player->OnDraw();  
        // EndScissorMode();
           
        //  scene.Draw();
        //  enemy->OnDraw();
        //  player->OnDraw();  

    //    // setViewPort((float)screenWidth/2, 0, (float)screenWidth/2, (float)screenHeight);

         scene->Draw();
    //     enemy->OnDraw();
    //     player->OnDraw();      
    //     End2D();

        
        
         if (IsMouseButtonDown(0))
        {
            Node* node = scene->MousePick();
            if (node!=nullptr)
            {
                TraceLog(LOG_INFO, "node %s", node->getName().c_str());
                node->done = true;
            }
               
        }
       
      
      


        EndDrawing();
     
    }

    // delete player;
    // delete enemy;

    Assets::Instance().clear();
    scene->Clear();
    delete scene;
    CloseWindow();        


    return 0;
}