#include "RayGot.hpp"
#include "Utils.hpp"
#include <raymath.h>

float skewX = 0.0f;
float skewY = 0.0f;

const int screenWidth =  25*24  *2;
const int screenHeight = 15*24  *2;


Color RandomRGBColor()
{
    Color c;
    c.r =(unsigned char) GetRandomValue(0, 255);
    c.g =(unsigned char) GetRandomValue(0, 255);
    c.b =(unsigned char) GetRandomValue(0, 255);
    c.a = 255;
    return c;
}

int sign (float x)
{
    if (x > 0)
        return 1;
    if (x < 0)
        return -1;
    return 0;
}


class Bullet : public Node2D
{
    public:
    float angle;
    float life = 0;
        Bullet(float x, float y, float angle):Node2D("bullet")
        {
            setSize(16,16/2);
            scale = {1.0,1.0};
            origin = {16/2,16/2};
            position = {x,y};
            this->angle = angle;
            Sprite2D *sprite = new Sprite2D("bullet","props");
            RectangleShape2D *shape = new RectangleShape2D(10, 16/2,10,8);
            shape->setVisible(true);
            addChild(shape);
            collidable = true;
            sprite->clip = {16,0,16,16};
            if (angle == 180)
            {
                sprite->flipX = true;
            }
            addChild(sprite);

        }
        void update(double deltaTime)
        {
            advance(1,angle);
            life += deltaTime;
            if (life > 1.5)
            {
               done = true;
            }
        }
        void OnCollision(Node *n)
        {
            Log(LOG_INFO, "Collide %s" ,n->name.c_str());
            
            
        }
};

  
class Physics :public Node2D
{
    public:
    Vector2 velocity;
    Vector2 acceleration;
    Vector2 friction;
    Vector2 maxVelocity;
    Vector2 gravity;
    Node *solid;
    bool onGround;
    Scene *scene;

    Physics(const std::string &name,Scene *scene):Node2D(name)
    {
        velocity = {0,0};
        acceleration = {0,0};
        friction = {0,0};
        maxVelocity = {0,0};
        gravity = {0,0};
        onGround = false;
        this->scene = scene;
        solid = scene->Find("solid");
    }
    void physics_update(double dt)
    {
        onGround = false;

        velocity.x += acceleration.x ;
        velocity.y += acceleration.y ;
        velocity.y += gravity.y;

   
        moveBy(velocity.x,velocity.y,solid,true);

        

		checkMaxVelocity();

    }

    virtual bool moveCollideY(Node *n)
    {
        if (velocity.y * sign(gravity.y) > 0)
		{
			onGround = true;
		}
		velocity.y = 0;

		velocity.x *= friction.x;
		if (abs(velocity.x) < 0.5) velocity.x = 0;
		
        return true;
    }
    virtual bool moveCollideX(Node *n)
    {
        velocity.x = 0;
  		velocity.y *= friction.y;
		if (abs(velocity.y) < 1) velocity.y = 0;
		
        return true;
    }
    
    void checkMaxVelocity()
    {
        if (maxVelocity.x > 0 && abs(velocity.x) > maxVelocity.x)
		{
			velocity.x = maxVelocity.x * sign(velocity.x);
		}

		if (maxVelocity.y > 0 && abs(velocity.y) > maxVelocity.y)
		{
			velocity.y = maxVelocity.y * sign(velocity.y);
		}
    }
  
};


class  Player : public Physics
{
    public:

    float kMoveSpeed = 0.8f;
	int   kJumpForce= 19;
    AnimatedSprite2D *sprite;
    Sprite2D *muzzle;
    RectangleShape2D *shape;
    bool crouch = false;
    bool shot=false;
    float coolDown = 0;
    float shootTimer = 0;
    

    Player(Scene *scene):Physics("player",scene)
    {
        
     

        
        
    
    }
    void ready()
    {
        setSize(40,35);
        origin = {24,20};
        

        maxVelocity.y = kJumpForce;
        maxVelocity.x = kMoveSpeed * 4;
        gravity.y = 1.0f;
        friction.x = 0.82f; // floor friction
        friction.y = 0.99f; // wall friction
        

     shape = new RectangleShape2D(35, 35,20,20);
     shape->setVisible(true);
     
     addChild(shape);

       sprite = new AnimatedSprite2D("idle");
       sprite->addFrame("idle", "red_idle", 6, 48, 48);
       sprite->addFrame("run", "red_run", 9, 288/6, 48);
       sprite->addFrame("jump", "red_jump", 8, 48, 48);
       sprite->addFrame("crouch", "red_crouch", 8, 48, 48);
       sprite->play("idle", true);

        addChild(sprite);

        muzzle = new Sprite2D("flash","flash");
        addChild(muzzle);
        muzzle->position.x = 40;
        muzzle->position.y = 17;
        muzzle->color.a = 0;


        position = {300,250};
        coolDown = 0.2f;
        


    }
    void update(double deltaTime)
    {

       acceleration.x = acceleration.y = 0;

        shootTimer += deltaTime;


       if (IsMouseButtonDown(MOUSE_LEFT_BUTTON) && shootTimer >= coolDown)
       {
              float angle = (sprite->flipX )?180:0;
              Vector2 pos={0,5} ;
              pos = muzzle->getWorldPosition(pos);
              Node *bullet = new Bullet(pos.x,pos.y,angle);
              scene->Add(bullet);
              muzzle->color=WHITE;
              shot=true;
               shootTimer = 0.0f;
              
       }

        if (shot)
        {
            muzzle->color.a -= 25;
            if (muzzle->color.a <= 25)
            {
                shot=false;
                muzzle->color.a = 0;
                
            }
        }

        if (IsKeyDown(KEY_A)) 
        {
           acceleration.x = -kMoveSpeed;
           crouch=false;
        }
        
         if (IsKeyDown(KEY_D)) 
         {
            acceleration.x = kMoveSpeed;
            crouch=false;
         }

        if (IsKeyDown(KEY_W) && onGround) 
        {
           acceleration.y = -sign(gravity.y) * kJumpForce;
           crouch=false;
        }

        if (IsKeyDown(KEY_S) && onGround && !crouch) 
        {
            	crouch=true;
        }

        if (crouch)
        {
            shape->height = 25;
            shape->offset.y = -10;
            muzzle->position.y = 22;
            
        } else 
        {
            
            shape->offset.y = 0;
            shape->height = 35;
            muzzle->position.y = 17;
        }




        this->physics_update(deltaTime );


        if (velocity.x < 0)
		{
			sprite->flipX = true; // left
            muzzle->position.x = 0;
            muzzle->flipX = true;
		}
		else if (velocity.x > 0)
		{
			sprite->flipX = false; // right
            muzzle->position.x = 40;
            muzzle->flipX = false;
		}

        if (onGround)
		{
			if (velocity.x == 0)
			{
				
                if (crouch)
                {
                        sprite->play("crouch",false);
                        
                                           
                } else 
                {
                    sprite->play("idle", true);
                }
			}
			else
			{
				sprite->play("run", true);
			}
		}
		else
		{
			sprite->play("jump", false);
		}

        

    }
    void draw()
    {
     
        // moveBy(velocity.x, velocity.y,solid,true);

        // if (shape->Collide(position.x,position.y, solid))
        // {
        //     DrawText("Collide", 20, 200, 20, RED);
        // } else 
        // {
        //     DrawText("No Collide", 20, 200, 20, RED);
        // }

          DrawText(TextFormat("Groudn %d ",onGround), 20, 200, 20, RED);

          
    }

};




class MainState : public State 
{
    public:
    Scene *scene;
 
    TileMap *map;   
    Vector2 scroll; 
    Player *player;

    MainState():State("MainState")
    {
       
    }
    void ready()
    {
  
         scene = new Scene();    
         Game::Instance().setClearColor({0,0,45,255});



        map = new TileMap("tile",30,20,24,24);
        map->SetColor({140,150,180,255});
        
        //map->LoadFromString(tiles,-1);
        map->LoadFromFile("assets/map.txt");
        //map->Replace(3, 0);
      //  map->visible = false;

        Node* solids = map->CreateSolids("solid", {0,1,2,4,6,7,8,9,10,11,12,13,14,15});
        
        scene->Add(map);
        scene->Add(solids);



        player = new Player(scene);

        scene->Add(player);

        
        View* view = getDefaultView();
        float size =10;
       // view->setViewPort(size, size, getWidth()-size, getHeight()-size);
        view->setOffset(view->getWidth()/2, getHeight()/2);
      view->setZoom(2.0f);

        
        

    }
    void update()
    {
        scene->Update();
        scene->Collisions();
 

    
          if (IsKeyPressed(KEY_P))
        {
           NodeEmitter2D* emitter = new NodeEmitter2D("emitter","particle", 20, true);
           emitter->SetFrequency(60);
           emitter->setSize(50,50);
            float life = 0.8;

            emitter->SetLife(life);
            emitter->SetAlphaStart(255, 0);
            emitter->SetAlphaEnd(0, life);
           
            
            emitter->SetSizeStart(0.5, 0);
            emitter->SetSizeEnd(1.2f, life);
            emitter->SetColorStart(55, 55, 55, 0);
            emitter->SetColorEnd(255, 255, 255, life*2);
            emitter->SetStartZone(-2, -2, 2, 2);
            emitter->SetDirection(0, 20);
            emitter->SetSelocityRange(0.5,2);
            emitter->position = {GetMouseX(),GetMouseY()};
            scene->Add(emitter);
        }



        
    }
    void render()
    {
        View* view = getDefaultView();
 

        scroll = Vector2Lerp(scroll, player->position, 0.1f);
        if (scroll.x >= 418)
            scroll.x = 418;
        if (scroll.y >= 300)
            scroll.y = 300;
        if (scroll.x <= 300)
            scroll.x = 300;
        if (scroll.y <= 185)
            scroll.y = 185;


        
       view->folow(scroll); 


        view->begin();
        scene->Render(view);   
        view->end();
        DrawText(TextFormat(" %f %f",scroll.x,scroll.y), getWidth()/2, 20, 20, RED);



 
    // DrawRectangle(x-5, y-5, 170,80, BLACK);
    // DrawFPS(x, y);
    int tile = map->GetWorldTile(GetMouseX(), GetMouseY());  
     DrawText(TextFormat("Objects: %i/%d", scene->Count(),scene->RenderedObjects()),20,20,18, LIME);
    DrawText(TextFormat("Tile: %i", tile),20,40,18, LIME);
        
    }
    void destroy()
    {
        delete scene;
    }

};




int main()
{
    Game &game = Game::Instance();
    game.Init(screenWidth, screenHeight, "RayGot");

    Assets::Instance().loadGraph("particle", "fire.png");
    Assets::Instance().loadGraph("tile", "tiles.png");
    Assets::Instance().loadGraph("props", "props_16x16.png");
    Assets::Instance().loadGraph("bullet", "SpongeBullet.png");
    Assets::Instance().loadGraph("flash", "MuzzleFlash.png");

    Assets::Instance().loadGraph("red_idle", "Gunner_Red_Idle.png");
    Assets::Instance().loadGraph("red_run", "Gunner_Red_Run.png");
    Assets::Instance().loadGraph("red_jump", "Gunner_Red_Jump.png");
    Assets::Instance().loadGraph("red_crouch", "Gunner_Red_Crouch.png");



    game.AddState(new MainState());
    game.ChangeState("MainState");
    while (game.IsRunning())
    {
        game.Update();
        game.Render();
    }
    game.Quit();


}